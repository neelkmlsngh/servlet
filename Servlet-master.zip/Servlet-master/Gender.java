package com.niit.training.servlet;

public enum Gender {
	Male('M'), Female('F');
	public char type;

	Gender(char type) {
		this.type = type;
	}

	public static Gender getGenderType(char type) {
		for (Gender typ : Gender.values()) {
			if (typ.type == type)
				return typ;
		}
		return null;
	}

}
