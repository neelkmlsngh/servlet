package com.niit.training.servlet;

public class Person {
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	private String name;
	private int age;
	Gender gender;

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Person(String name, int age, Gender gender) {
		// TODO Auto-generated constructor stub
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}

	public static void main(String args[]) {

		Person c1 = new Person("Ankush", 22, Gender.Male);
		Person c2 = new Person("Amita", 23, Gender.Female);

		// System.out.println(c1.compareTo(c2));
		// Comparator1 c = new Comparator1();
		// System.out.println(c.compare(c1, c2));
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", gender=" + gender + "]";
	}

	@Override
	public int hashCode() {

		return 7;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
